import java.util.Scanner;

public class book_detail {

    Scanner s=new Scanner(System.in);
    int n;
    book b[]=new book[20];

    public void createBooks(){

        System.out.println("enter the number of books");
        n=s.nextInt();

        for (int i=0,count=1;i<n;i++){
            b[i]=new book();
            System.out.println("enter the details for book"+count++);
            System.out.println("enter book title");


            String temp=s.next();
            b[i].setBook_title(temp);

            System.out.println("enter book price");
            int x=s.nextInt();
            if (x<0) {
                System.out.println("enter valid Book_price");
                i--;
                count--;
                continue;
            }
            else
            {
                b[i].setBook_price(x);
            }

        }
    }

    public void showBooks(){
        for (int i=0,count=1;i<n;i++) {
            System.out.println("\n\nDetails of Book"+count++);
            System.out.println("book title is:" + b[i].getBook_title());
            System.out.println("book price is:" + b[i].getBook_price());
        }
    }

    public static void main(String[] args){
        book_detail bd=new book_detail();
        bd.createBooks();
        bd.showBooks();

    }

}
