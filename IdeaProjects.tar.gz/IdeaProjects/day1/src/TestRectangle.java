import java.awt.*;
import java.util.Scanner;

public class TestRectangle {

    public static void main(String[] args){

        Rectangle[] r = new Rectangle[5];
        Scanner sc=new Scanner(System.in);
        float temp=0,temp1=0;


        for (int i=0,count=1;i<5;i++){

            r[i]=new Rectangle();

            System.out.println("enter the length and breadth for rectangle"+count+++":");
            temp = sc.nextFloat();
            temp1 = sc.nextFloat();
            if(temp>0 && temp1>0)
            {
                r[i].setLength(temp);
                r[i].setBreadth(temp);
            }
            else {
                System.out.println("enter valid length and breadth");
                i=i-1;
                count=count-1;
            }
        }


        for(int i=0,count=1;i<5;i++){
            System.out.println("\n\n1details of rectangle:"+count++);
            r[i].display();
        }


    }
}
