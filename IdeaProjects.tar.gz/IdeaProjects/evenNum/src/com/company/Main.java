package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Scanner sc=new Scanner(System.in);
        System.out.print("enter the valu for n:");
        int n=sc.nextInt();
        System.out.println("even numbers are :");
        for(int i=0;i<=n;i=i+2){
            System.out.print(" "+i);
        }


    }
}
