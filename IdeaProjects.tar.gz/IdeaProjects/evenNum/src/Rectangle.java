package com.company;

import java.util.Scanner;

public class Rectangle {
    public static void Main(){
        System.out.print("sadf");
    }
}
