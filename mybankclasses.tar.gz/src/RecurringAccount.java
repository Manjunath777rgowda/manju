import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;
import static java.lang.Integer.parseInt;
import static java.time.temporal.ChronoUnit.DAYS;

public class RecurringAccount {

    private int refferenceNumber=0;
    private int depositPeriod;
    private LocalDate depositDate;
    private double accountBalance;
    private double initialDeposit;
    private LocalDate transactionDate;

    public int getRefferenceNumber() {
        return refferenceNumber;
    }

    public void setRefferenceNumber(int refferenceNumber) {
        this.refferenceNumber = refferenceNumber;
    }

    public int getDepositPeriod() {
        return depositPeriod;
    }

    public void setDepositPeriod(int depositPeriod) {
        this.depositPeriod = depositPeriod;
    }

    public LocalDate getDepositDate() {
        return depositDate;
    }

    public void setDepositDate(LocalDate depositDate) {
        this.depositDate = depositDate;
    }

    public double getInitialDeposit() {
        return initialDeposit;
    }

    public void setInitialDeposit(double initialDeposit) {
        this.initialDeposit = initialDeposit;
    }

    public LocalDate getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDate transactionDate) {
        this.transactionDate = transactionDate;
    }

    public void setAccountBalance(double balance) {
        this.accountBalance = balance;
    }

    public double getAccountBalance() {
        return this.accountBalance;
    }

    //public void withdraw(Customer customer){System.out.println("You cannot withdraw!");}

    public void interest() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy");
        if (DAYS.between(depositDate, LocalDate.now()) == 365 * depositPeriod) {
            setAccountBalance(getAccountBalance() + (getAccountBalance() * depositPeriod * (6 / 100)));
            getAccountBalance();
        } else {
            System.out.println("Interest not applied");
        }
    }

    public void depositTimePeriod() {
        Scanner input = new Scanner(System.in);
        System.out.println("Choose the deposit period between 1 to 10 years");
        String depositPeriod = input.next();
        while (!Pattern.matches("[1-9]|[1][0]", depositPeriod)) {
            System.out.println("Invalid deposit period");
            depositPeriod = input.next();
        }
        this.depositPeriod = parseInt(depositPeriod);
    }

    public void deposit(int firstTransaction) {
        if (firstTransaction == 1) {
            this.depositDate = LocalDate.now();
            //this.depositDate=LocalDate.of(2018, Month.JULY, 7);

            Scanner input = new Scanner(System.in);
            System.out.println("\nhow much you want to deposit");
            try {
                double deposit = input.nextDouble();
                while (deposit <= 0 || deposit < getAccountBalance() || deposit > 100000) {
                    System.out.println("Enter proper amount.");
                    deposit = input.nextDouble();
                }
                setAccountBalance(getAccountBalance() + deposit);
                this.initialDeposit = deposit;
                this.transactionDate = depositDate;
                System.out.println("Next deposit on : " + transactionDate.plusDays(31));
            } catch (Exception e) {
                System.out.println("Invalid input");
            }
        } else {
            Scanner input = new Scanner(System.in);
            if (DAYS.between(depositDate, LocalDate.now()) != 31) {
                System.out.println("Deposit the amount after a month");
            } else {
                System.out.println("How much you want to deposit?");
                try {
                    double deposit = input.nextDouble();
                    while (deposit <= 0 || deposit >= 100000 || deposit != this.initialDeposit) {
                        System.out.println("Enter proper amount.");
                        deposit = input.nextDouble();
                    }
                    setAccountBalance(getAccountBalance() + deposit);
                } catch (Exception e) {
                    System.out.println("Invalid input");
                }
            }
        }
    }

    public void CreateRD() {

        RecurringAccount rd = new RecurringAccount();
        Validation v = new Validation();
        Scanner sc = new Scanner(System.in);
        String temp;
        boolean flag = true;


        Random rand = new Random();
        int number = rand.nextInt(999) + 1000;
        rd.refferenceNumber = number;

        rd.depositDate=java.time.LocalDate.now();

        while(flag)
        {
            System.out.println("Enter Amount to Deposite");
            temp=sc.next();
            rd.initialDeposit=v.choiceValidation(temp);
            if(rd.initialDeposit>=1000)
            {
                flag=false;
            }
            else System.out.println("Please enter valid Amount");
        }

        flag=true;

        while(flag)
        {
            System.out.println("\n\nEnter Deposite Period in Months\n***Warning!!! Month Should be greater than 6 months and lesser than 120 months");
            temp=sc.next();
            rd.depositPeriod=v.choiceValidation(temp);
            if(rd.depositPeriod>=6 && rd.depositPeriod<=120)
            {
                flag=false;
            }
            else System.out.println("Please enter valid Period");
        }


        if (setRdDetails(rd))
        {
            // depositeList.add(rd);
            System.out.println("\n\n####-----Deposited Successfully-----####\n\n");
        }

        }



    public boolean setRdDetails(RecurringAccount rd) {
        Scanner sc=new Scanner(System.in);
        String str;
        int choice;
        System.out.println("-----------------------------------Verify your details------------------------------");
        System.out.println("Refference Number    : "+rd.refferenceNumber);
        System.out.println("Deposite amount      : "+rd.initialDeposit);
        System.out.println("Deposite Period      : "+rd.depositPeriod);
        System.out.println("Deposite Date        : "+rd.depositDate);
        System.out.println("------------------------------------------------------------------------------------\n");
        while (true)
        {
            System.out.println("Please Enter your Choice");
            System.out.println("1-Done 2-Cancel");
            str=sc.next();
            Validation v=new Validation();
            choice=v.choiceValidation(str);
            switch (choice)
            {
                case 1:
                    return true;
                case 2:
                    return false;
                default:System.out.println("Invalid choice");
                    break;
            }
        }
    }

    public void Rddetails()    {
       /* if (depositeList.size()==0)
        {
            System.out.println("\n\n----Sorry!!!! There is no Deposite Available----\n\n");
            return;
        }
        System.out.println("\n\n\n-------------------------------Reccuring Deposite Recods------------------------------------");
        System.out.println("\nSl no\tRefference_Id\tDeposite_Amount\tDeposite_Date\n");

        for (int i=0;i<depositeList.size();i++)
        {
            ReccuringAccount temp=new ReccuringAccount();
            temp=depositeList.get(i);
            System.out.println((i+1)+"\t\t"+temp.refferenceNumber+"\t\t\t"+temp.initialamount+"\t\t\t"+temp.depositeDate+"\n\n");
        }
        System.out.println("------------------------------------------------------------------------------------------\n\n\n");
   */ }

    public void ViewDetails() {
       /* Scanner sc = new Scanner(System.in);
        Validation v = new Validation();
        boolean flag=true;
        int refferenceId;

        do {
            System.out.println("Enter the Refferece number");
            String str = sc.next();
            refferenceId = v.choiceValidation(str);
            if (refferenceId==0)
                System.out.println("Invalid Refference ID");
        }while (refferenceId==0);

        if (depositeList.size() > 0)
        {

            for (int i=0;i<depositeList.size();i++)
            {
                ReccuringAccount temp = new ReccuringAccount();
                temp = depositeList.get(i);

                if (temp.refferenceNumber == refferenceId)
                {
                    System.out.println("\n\n------------------------------Reccuring Deposite Details------------------------------");
                    System.out.println("|   |                       | ");
                    System.out.println("|1. | Refference Number     | " + temp.refferenceNumber);
                    System.out.println("|2. | Nominee Name          | " + temp.nomineeName);
                    System.out.println("|3. | Deposite amount       | " + temp.initialamount);
                    System.out.println("|4. | Deposite Period       | " + temp.period);
                    System.out.println("|5. | Deposite Date         | " + temp.depositeDate);
                    System.out.println("|6. | Installment Remaining | " + (temp.period - 1));
                    System.out.println("|7. | Total Deposite        | " + (temp.initialamount * temp.period));
                    System.out.printf("|8. | Intrest               | %.2f\n", ((temp.initialamount * temp.period) * 0.04));
                    System.out.println("|9. | Total Amount          | " + (((temp.initialamount * temp.period) * 0.04) + (temp.initialamount * temp.period)));
                    System.out.println("|   |                       | ");
                    System.out.println("------------------------------------------------------------------------------------\n\n");
                    flag=false;
                    return;
                }
            }


        }
        else{
            System.out.println("Sorry!!! There is no record for Refference Number " + refferenceId);
            flag=false;
        }

        if (flag==true)
        {
            System.out.println("Sorry!!! There is no record for Refference Number " + refferenceId);

        }*/
    }

    public void functionality(String accnumber) {

        Scanner sc = new Scanner(System.in);
        Validation v = new Validation();
        Details customer = new Details();

        boolean flag = true;
        int choice;
        if (accnumber != null) {
            while (true) {
                System.out.println("Press 1-Create_RD 2-Show_All_Deposite 3-View_Details 4-logout");
                String str = sc.next();
                choice = v.choiceValidation(str);
                switch (choice) {
                    case 1:
                        CreateRD();
                        break;
                    case 2:
                        Rddetails();
                        break;
                    case 3:
                        ViewDetails();
                        break;

                    case 4:
                        System.out.println("\n\n####----Logged out Successfully----####");
                        return;

                    default:
                        System.out.println("\n\nInvalid choice");
                }
            }
        }
    }

}

