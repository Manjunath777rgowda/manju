public class temp {
    public static void main(String[] args)
    {
        savingsAccount s=new savingsAccount();
        System.out.println("class name="+s.getClass().getName());
    }
}
