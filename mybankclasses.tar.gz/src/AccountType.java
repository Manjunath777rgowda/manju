public abstract class AccountType {

    public abstract boolean OpenAccount();
    //public abstract boolean ConfirmAccount();
}
