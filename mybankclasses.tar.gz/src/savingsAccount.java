import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.imageio.spi.ServiceRegistry;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.HashMap;
import java.util.Scanner;

@Entity
@Table(name="savingsAccount")
public class savingsAccount extends AccountType {
    HashMap<Integer, Details> account = new HashMap();
    HashMap<Integer,Float> balanceSheet=new HashMap<Integer,Float>();


    //Transaction t;

    @Id
    @Column(name="accountNumber")


    @Override
    public boolean OpenAccount() {
        Details sd;
        System.out.println("****Savings account****");
        sd = new Details();
        String number=sd.getInputDetails();
        //setSd();
        savingsAccount s=new savingsAccount();

        if (number == null) {
            System.out.println("\n\n****Savings account not created****\n\n");
            return false;
        } else {
            System.out.println("\n\n**********Savings account Created successfully**********\n\n");
            return true;
        }
    }

    public boolean ConfirmAccount() {
        Details d=new Details();


        int accountNumber = 0;
        String str;
        boolean flag = true;
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Enter your Account Number\n");
            str = sc.next();
            accountNumber = Integer.parseInt(str);
            flag = false;
        } catch (Exception e) {
            System.out.println("Invalid Account number");
            return false;
        }

        System.out.println("Enter your Password\n");
        str = sc.next();

        connectJDBC con=new connectJDBC();
       // d=con.retrive(d,accountNumber);

        if ((d.getAccountNumber().equals(accountNumber)) && (d.getPassword().equals(str)) ){
            System.out.println("####Successfully logged in####");
    //        functionality(d);
        } else {
            System.out.println("account not exist");
            return false;
        }
        return false;
    }

  /*public void functionality(Details d) {
            Scanner sc = new Scanner(System.in);
            int choice;
            Validation v = new Validation();
            Transaction t=new Transaction();
        float temp=d.getInitialamount();
        //balanceSheet.put(accountNumber,temp);
            while (true) {
                System.out.println("Press 1-Deposite 2-Balance 3-Withdraw 4-logout");
                String str = sc.next();
                choice = v.choiceValidation(str);
                switch (choice) {
                    case 1:temp=t.Deposite(temp);

                        //balanceSheet.put(accountNumber,temp);
                          break;
                    case 2: t.Balance(balanceSheet.get(accountNumber));
                        break;
                    case 3:temp=t.Withdraw(temp,0);
                        balanceSheet.put(accountNumber,temp);
                        break;
                    case 4:System.out.println("####----Logged out Successfully----####");
                        return;
                    default: System.out.println("\n\nInvalid choice");
                }
            }

        }*/
}