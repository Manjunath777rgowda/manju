import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class connectJDBC {

    public boolean insert(Object o) {

        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(o.getClass())
                .buildSessionFactory();
        //create session
        Session session = factory.getCurrentSession();

        try {
            session.beginTransaction();
            session.save(o);
            session.getTransaction().commit();
          //  System.out.println("done!!");
            return true;
        }

        catch (Exception e) {
            System.out.println("Error while connecting");
            return false;
        }

        finally {
            factory.close();

        }

    }

    public Details retrive(Object o,String accountNumber) {

        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(o.getClass())
                .buildSessionFactory();
        //create session
        Session session = factory.getCurrentSession();

        try {
            session.beginTransaction();
            Details d=new Details();
            d=(Details)session.get(o.getClass(),accountNumber);
            // session.save(o);
            session.getTransaction().commit();
            //System.out.println("done!!");
            return d;
        }

        catch (Exception e) {
            // e.printStackTrace();
            return null;
        }

        finally {
            factory.close();
        }

    }

    public Details update(Object o,String accountNumber) {

        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(o.getClass())
                .buildSessionFactory();
        //create session
        Session session = factory.getCurrentSession();

        try {
            session.beginTransaction();
            Details d=new Details();
            session.update(o);
            session.getTransaction().commit();
            //System.out.println("done!!");
            return d;
        }

        catch (Exception e) {
            // e.printStackTrace();
            return null;
        }

        finally {
            factory.close();

        }

    }

  /*  public static void main(String args[]){
        String jdbcUrl="jdbc:mysql://localhost:3306/Example";
        String user="root";
        String password="mysqlroot";

        try{
            System.out.println("connecting to database:"+jdbcUrl);
            Connection myConn = DriverManager.getConnection(jdbcUrl,user,password);
            System.out.println("connection established!!");
        }

        catch(Exception exc ){
            exc.printStackTrace();
        }


    }*/

}