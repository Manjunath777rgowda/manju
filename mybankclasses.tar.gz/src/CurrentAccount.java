/*import java.util.HashMap;
import java.util.Scanner;

public class CurrentAccount extends AccountType {

    HashMap<Integer, Details> account = new HashMap();
    HashMap<Integer, Float> balanceSheet = new HashMap<Integer, Float>();

    Details sd;
    float initialamount;
    Transaction t;


    public void setSd(Details sd) {
        this.sd = sd;
    }

    public Details getSd() {
        return sd;
    }


    @Override
    public boolean OpenAccount() {

        Scanner sc = new Scanner(System.in);
        Validation v = new Validation();
        String str;
        System.out.println("****Current account****");
        sd = new Details();
        boolean flag=true;

        //System.out.println("\n\nWarning!!!!! Initial Balance should be more than 20000");
        setSd(sd.getInputDetails(2));

        if (sd == null) {
            System.out.println("\n\n****Current account not created****\n\n");
            return false;
        } else
            {
                while(flag)
            {
                System.out.println("Enter Initial Amount");
                str=sc.next();
                initialamount=v.choiceValidation(str);
                if(initialamount>=20000)
                {
                    flag=false;
                }
                else System.out.println("Warning!!!!! Initial Balance should be more than 20000");
            }
            account.put(sd.getAccountNumber(), getSd());
            System.out.println("\n\n**********Current account Created successfully**********\n\n");
            return true;
        }
    }

    public boolean ConfirmAccount() {
        int accountNumber = 0;
        String str;
        boolean flag = true;
        Scanner sc = new Scanner(System.in);

            try {
                System.out.println("Enter your Account Number\n");
                str = sc.next();
                accountNumber = Integer.parseInt(str);
            } catch (Exception e) {
                System.out.println("Invalid Account number");
                return false;
            }

            System.out.println("Enter your Password\n");
            str = sc.next();

            if ((account.containsKey(accountNumber)) && (account.get(accountNumber).getPassword()).equals(str)) {
                System.out.println("####Successfully logged in####");
                functionality(account.get(accountNumber).getAccountNumber());
            } else {
                System.out.println("account not exist");
                return false;
            }

        return false;
    }

    public void functionality(int accountNumber) {
        t=new Transaction();
        Scanner sc = new Scanner(System.in);
        int choice;
        Validation v = new Validation();
        float temp=initialamount;
        balanceSheet.put(accountNumber,temp);
        while (true) {
            System.out.println("Press 1-Deposite 2-Balance 3-Withdraw 4-logout");
            String str = sc.next();
            choice = v.choiceValidation(str);
            switch (choice) {
                case 1:temp=t.Deposite(temp);
                    balanceSheet.put(accountNumber,temp);
                    break;
                case 2: t.Balance(balanceSheet.get(accountNumber));
                    break;
                case 3:temp=t.Withdraw(temp,initialamount);
                    balanceSheet.put(accountNumber,temp);
                    break;
                case 4:System.out.println("####----Logged out Successfully----####");
                    return;
                default: System.out.println("\n\nInvalid choice");
            }
        }

    }
}
*/