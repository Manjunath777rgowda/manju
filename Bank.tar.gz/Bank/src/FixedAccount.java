public class FixedAccount extends AccountType{

    @Override
    public boolean OpenAccount() {
        System.out.println("fixed account");
        return false;
    }
}
