import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

public class FixedAccount extends AccountType{

        private int refferenceNumber=0;
        private String nomineeName=null;
        private LocalDate depositeDate;
        private String relationship;
        private int period=0;
        private String payBack;

        HashMap<Integer, StoreDetails> account = new HashMap();
        ArrayList<FixedAccount> depositeList=new ArrayList<>();

        StoreDetails sd;
       FixedAccount fd;
        float initialamount=0;
        Transaction t;

        public void setSd(StoreDetails sd) {
            this.sd = sd;
        }

        public StoreDetails getSd() {
            return sd;
        }


        @Override
        public boolean OpenAccount() {

            Scanner sc = new Scanner(System.in);
            Validation v = new Validation();
            String str;
            System.out.println("****Fixed account****");
            sd = new StoreDetails();
            boolean flag=true;

            setSd(sd.getInputDetails());

            if (sd == null) {
                System.out.println("\n\n****Fixed account not created****\n\n");
                return false;
            } else
            {
                account.put(sd.getAccountNumber(), getSd());
                System.out.println("\n\n**********Fixed account Created successfully**********\n\n");
                return true;
            }
        }


        public boolean ConfirmAccount() {
            int accountNumber = 0;
            String str;
            Scanner sc = new Scanner(System.in);

            try {
                System.out.println("Enter your Account Number\n");
                str = sc.next();
                accountNumber = Integer.parseInt(str);
            } catch (Exception e) {
                System.out.println("Invalid Account number");
                return false;
            }

            System.out.println("Enter your Password\n");
            str = sc.next();

            if ((account.containsKey(accountNumber)) && (account.get(accountNumber).getPassword()).equals(str)) {
                System.out.println("\n\n####Successfully logged in####");
                functionality();
            } else {
                System.out.println("account not exist");
                return false;
            }
            return false;
        }

        public void functionality() {
            Scanner sc = new Scanner(System.in);
            int choice;
            Validation v = new Validation();
            while (true) {
                System.out.println("Press 1-Create_FD 2-Show_All_Deposite 3-View_Details 4-logout");
                String str = sc.next();
                choice = v.choiceValidation(str);
                switch (choice) {
                    case 1: CreateFD();
                        break;
                    case 2: Fddetails();
                        break;
                    case 3 :ViewDetails();
                        break;

                    case 4:System.out.println("\n\n####----Logged out Successfully----####");
                        return;

                    default: System.out.println("\n\nInvalid choice");
                }
            }

        }

        public void CreateFD() {

            fd = new FixedAccount();
            Validation v = new Validation();
            Scanner sc = new Scanner(System.in);
            String temp;
            int choice;
            boolean flag = true;


            Random rand = new Random();
            int number = rand.nextInt(999) + 1000;
            fd.refferenceNumber = number;

            fd.depositeDate=java.time.LocalDate.now();

            while(flag)
            {
                System.out.println("Enter Amount to Deposite");
                temp=sc.next();
                fd.initialamount=v.choiceValidation(temp);
                if(fd.initialamount>=1000)
                {
                    flag=false;
                }
                else System.out.println("Please enter valid Amount");
            }

            flag=true;

            while(flag)
            {
                System.out.println("\n\nEnter Deposite Period in Months\n***Warning!!! Month Should be greater than 6 months and lesser than 120 months");
                temp=sc.next();
                fd.period=v.choiceValidation(temp);
                if(fd.period>=6 && fd.period<=120)
                {
                    flag=false;
                }
                else System.out.println("Please enter valid Period");
            }


            flag=true;
            while (flag) {
                System.out.println("\n\nIntrest Paid on 1-Monthly 2-Quaterly 3-On_Maturity");
                String str = sc.next();
                choice = v.choiceValidation(str);
                switch (choice) {
                    case 1:
                        fd.payBack = "Monthly";
                        flag = false;
                        break;
                    case 2:
                        fd.payBack = "Quaterly";
                        flag = false;
                        break;
                    case 3:
                        fd.payBack = "On_Maturity";
                        flag = false;
                        break;
                    default:
                        System.out.println("\n\nInvalid choice");
                        flag = true;
                        break;
                }
            }

            do {
                System.out.println("Enter Nominee Name");
                temp = sc.next();
                flag = v.nameValidation(temp);
                if (flag) {
                    fd.nomineeName=temp;
                } else System.out.println("Enter valid Name");
            } while (!flag);

            flag=true;
            while (flag) {
                System.out.println("Select Relationship 1-Parents 2-Spouce 3-Sibling");
                String str = sc.next();
                choice = v.choiceValidation(str);
                switch (choice) {
                    case 1:
                        fd.relationship = "Parents";
                        flag = false;
                        break;
                    case 2:
                        fd.relationship = "Spouce";
                        flag = false;
                        break;
                    case 3:
                        fd.relationship = "Sibling";
                        flag = false;
                        break;
                    default:
                        System.out.println("\n\nInvalid choice");
                        flag = true;
                        break;
                }
            }

            if (setRdDetails())
            {
                depositeList.add(fd);
                System.out.println("\n\n####-----Deposited Successfully-----####\n\n");
            }

        }

        public boolean setRdDetails()
        {
            Scanner sc=new Scanner(System.in);
            String str;
            int choice;
            System.out.println("-----------------------------------Verify your details------------------------------");
            System.out.println("Refference Number    : "+fd.refferenceNumber);
            System.out.println("Deposite amount      : "+fd.initialamount);
            System.out.println("Deposite Period      : "+fd.period);
            System.out.println("Intrest Paid         : "+fd.payBack);
            System.out.println("Deposite Date        : "+fd.depositeDate);
            System.out.println("Nominee Name         : "+fd.nomineeName);
            System.out.println("Nominee Relationship : "+fd.relationship);
            System.out.println("------------------------------------------------------------------------------------\n");
            while (true)
            {
                System.out.println("Please Enter your Choice");
                System.out.println("1-Done 2-Cancel");
                str=sc.next();
                Validation v=new Validation();
                choice=v.choiceValidation(str);
                switch (choice)
                {
                    case 1:
                        return true;
                    case 2:
                        return false;
                    default:System.out.println("Invalid choice");
                        break;
                }
            }
        }

        public void Fddetails()
        {
            if (depositeList.size()==0)
            {
                System.out.println("\n\n----Sorry!!!! There is no Deposite Available----\n\n");
                return;
            }
            System.out.println("\n\n\n-------------------------------Fixed Deposite Recods------------------------------------");
            System.out.println("\nSl no\tRefference_Id\tDeposite_Amount\tDeposite_Date\n");

            for (int i=0;i<depositeList.size();i++)
            {
                FixedAccount temp=new FixedAccount();
                temp=depositeList.get(i);
                System.out.println((i+1)+"\t\t"+temp.refferenceNumber+"\t\t\t"+temp.initialamount+"\t\t\t"+temp.depositeDate+"\n\n");
            }
            System.out.println("------------------------------------------------------------------------------------------\n\n\n");
        }

        public void ViewDetails()
        {
            Scanner sc = new Scanner(System.in);
            Validation v = new Validation();
            boolean flag=true;
            int refferenceId;

            do {
                System.out.println("Enter the Refferece number");
                String str = sc.next();
                refferenceId = v.choiceValidation(str);
                if (refferenceId==0)
                    System.out.println("Invalid Refference ID");
            }while (refferenceId==0);

            if (depositeList.size() > 0)
            {

                for (int i=0;i<depositeList.size();i++)
                {
                    FixedAccount temp = new FixedAccount();
                    temp = depositeList.get(i);

                    if (temp.refferenceNumber == refferenceId)
                    {
                        if (temp.payBack.equals("Monthly"))
                        {
                            System.out.println("\n\n------------------------------Reccuring Deposite Details------------------------------");
                            System.out.println("|   |                       | ");
                            System.out.println("|1. | Refference Number     | " + temp.refferenceNumber);
                            System.out.println("|2. | Nominee Name          | " + temp.nomineeName);
                            System.out.println("|3. | Deposite amount       | " + temp.initialamount);
                            System.out.println("|4. | Deposite Period       | " + temp.period);
                            System.out.println("|5. | Deposite Date         | " + temp.depositeDate);
                             System.out.printf("|6. | Monthly Intrest       | %.2f\n", (((temp.initialamount) * 0.06)/temp.period));
                             System.out.printf("|7. | Toatl Intrest         | %.2f\n", ((temp.initialamount) * 0.06));
                            System.out.println("|   |                       | ");
                            System.out.println("------------------------------------------------------------------------------------\n\n");
                            flag=false;
                            return;
                        }
                        else if (temp.payBack.equals("Quaterly"))
                        {
                            float times=0;
                            times=temp.period/3;

                            System.out.println("\n\n------------------------------Reccuring Deposite Details------------------------------");
                            System.out.println("|   |                       | ");
                            System.out.println("|1. | Refference Number     | " + temp.refferenceNumber);
                            System.out.println("|2. | Nominee Name          | " + temp.nomineeName);
                            System.out.println("|3. | Deposite amount       | " + temp.initialamount);
                            System.out.println("|4. | Deposite Period       | " + temp.period);
                            System.out.println("|5. | Deposite Date         | " + temp.depositeDate);
                             System.out.printf("|6. | Quaterly Intrest      | %.2f\n", ((temp.initialamount) * 0.06)/times);
                             System.out.printf("|7. | Total Intrest         | %.2f\n", ((temp.initialamount) * 0.06));
                            System.out.println("|   |                       | ");
                            System.out.println("------------------------------------------------------------------------------------\n\n");
                            flag=false;
                            return;

                        }

                        else
                        {

                            System.out.println("\n\n------------------------------Reccuring Deposite Details------------------------------");
                            System.out.println("|   |                       | ");
                            System.out.println("|1. | Refference Number     | " + temp.refferenceNumber);
                            System.out.println("|2. | Nominee Name          | " + temp.nomineeName);
                            System.out.println("|3. | Deposite amount       | " + temp.initialamount);
                            System.out.println("|4. | Deposite Period       | " + temp.period);
                            System.out.println("|5. | Deposite Date         | " + temp.depositeDate);
                            System.out.printf("|6. | Intrest               | %.2f\n", ((temp.initialamount) * 0.06));
                            System.out.println("|7. | Total Amount          | " + (((temp.initialamount) * 0.06) + (temp.initialamount)));
                            System.out.println("|   |                       | ");
                            System.out.println("------------------------------------------------------------------------------------\n\n");
                            flag=false;
                            return;

                        }

                    }
                }


            }
            else{
                System.out.println("Sorry!!! There is no record for Refference Number " + refferenceId);
                flag=false;
            }

            if (flag==true)
            {
                System.out.println("Sorry!!! There is no record for Refference Number " + refferenceId);

            }
        }


    }

