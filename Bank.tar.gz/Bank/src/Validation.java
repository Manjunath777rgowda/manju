import java.io.Console;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Validation {

    public int choiceValidation(String str) {
        try {

            return Integer.parseInt(str);
        } catch (Exception e) {
            return 0;
        }
    }


    public boolean PhoneNumberValidation(String str) {
        try {
            int phoneNumber = Integer.parseInt(str);
            int length = String.valueOf(str).length();
            if (length == 10) {
                return true;
            } else {
                System.out.println("Phone number should be 10 digits");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Invalid Phone Number");
            return false;
        }
    }

    public boolean AdharNumberValidation(String str) {
        try {
            Long.parseLong(str);
            int length = String.valueOf(str).length();
            if (length == 12) {
                return true;
            } else {
                System.out.println("Adhar number should be 12 digits");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Invalid Adhar Number");
            return false;
        }
    }

    public boolean nameValidation(String str)
    {
        if (str.matches("[a-zA-Z]+$")) {
            return true;
        }
        else return false;
    }

    public boolean dateValidation(String str)
    {
        try{
            String pattern = "dd/mm/yyyy";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

            Date date = simpleDateFormat.parse(str);
            return true;
        }
        catch (Exception e)
        {
            System.out.println("Invalid date");
            return false;
        }

    }

    public void hidePassword()
    {

        try{
            Console c;
            c=System.console();
            String str=c.readLine();
            System.out.println("  sss "+str);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("invalid password");
        }


    }

}
