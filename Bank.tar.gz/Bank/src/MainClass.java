import java.util.Scanner;

public class MainClass{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int choice;
        Validation v=new Validation();
        AccountType sa=new SavingsAccount();
        AccountType ca=new CurrentAccount();
        AccountType fa=new FixedAccount();
        AccountType ra=new ReccuringAccount();

        while (true)
        {
            System.out.println("Press 1-CreateAccount 2-Existing_account 3-exit");

            String str=sc.next();
            choice=v.choiceValidation(str);
            switch (choice)
            {
                case 1:
                    boolean flag=true;
                    while (flag)
                    {
                        System.out.println("\n\nSlect Account Type");
                        System.out.println("1-Savings_account 2-Current_account 3-Fixed_account 4-Reccuring_account 5-Go_back 6-exit");

                        str=sc.next();
                        choice=v.choiceValidation(str);
                        switch (choice)
                    {
                        case 1: if (sa.OpenAccount()){
                                        flag=false;
                                    }
                            break;
                          case 2: if(ca.OpenAccount())
                          {
                              flag=false;
                          }
                            break;
                            case 3:
                            fa.OpenAccount();
                            break;
                            case 4:
                                if(ra.OpenAccount())
                                {
                                    flag=false;
                                }
                            break;
                            case 5: flag=false;
                            break;
                            case 6:System.exit(0);
                            break;
                        default:System.out.println("Invalid Choice\n"); break;
                    }
                }
                break;


                    case 2:
                     flag=true;
                    while (flag)
                    {
                        System.out.println("\n\n******Slect Account Type******");
                        System.out.println("1-Savings_account 2-Current_account 3-Fixed_account 4-Reccuring_account 5-Go_back 6-exit");

                        str=sc.next();
                        choice=v.choiceValidation(str);
                        switch (choice)
                        {
                            case 1: if (((SavingsAccount) sa).ConfirmAccount()==false){
                                    flag=false;
                                }
                                break;
                            case 2:if (((CurrentAccount) ca).ConfirmAccount()==false){
                                flag=false;
                            }
                                break;
                            case 3:
                                fa.OpenAccount();
                                break;

                                case 4:
                                    if (((ReccuringAccount) ra).ConfirmAccount()==false){
                                        flag=false;
                                    }
                                break;
                            case 5: flag=false;
                                break;
                            case 6:System.exit(0);
                                break;
                            default:System.out.println("Invalid Choice\n"); break;
                        }
                    }
                    break;

                case 3: System.exit(0);
                default:System.out.println("Invalid Choice\n"); break;
            }
        }
    }
}
