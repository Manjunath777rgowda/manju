import java.net.PasswordAuthentication;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class StoreDetails {
    private int accountNumber;
    private String accountName;
    private String fatherName;
    private Date dob;
    private String address;
    private long adharNumber;
    private int phoneNumber;
    private String password;
    StoreDetails sd;


    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setAdharNumber(long adharNumber) {
        this.adharNumber = adharNumber;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Date getDob() {
        return dob;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public long getAdharNumber() {
        return adharNumber;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public String getAddress() {
        return address;
    }

    public String getFathername() {
        return fatherName;
    }

    public String getPassword() {
        return password;
    }


    public StoreDetails getInputDetails()
    {
        sd=new StoreDetails();
        Validation v=new Validation();
        Scanner sc=new Scanner(System.in);
        String temp;
        boolean flag=false;


        Random rand=new Random();
        int number = rand.nextInt(999)+1000 ;
        sd.setAccountNumber(number);

      /* do {
            System.out.println("Enter Account Name");
            temp = sc.next();
            flag=v.nameValidation(temp);
            if (flag)
            {
                sd.setAccountName(temp);
            }
            else System.out.println("Enter valid Name");
        }while (!flag);

        do {
            System.out.println("Enter Father Name");
            temp = sc.next();
            flag=v.nameValidation(temp);
            if (flag)
            {
                sd.setFatherName(temp);
            }
            else System.out.println("Enter valid Name");
        }while (!flag);


        do {
            System.out.println("Enter Date of birth");
            temp = sc.next();
            flag=v.dateValidation(temp);
            if (flag)
            {
                try{
                    SimpleDateFormat format=new SimpleDateFormat("dd/mm/yyyy");
                    Date date=format.parse(temp);
                   sd.setDob(date);
                }
                catch (Exception e)
                {
                    System.out.println("Invalid Date");
                }

            }
        }while (!flag);

        System.out.println("Enter Address");
        temp=sc.next();
        sd.setAddress(temp);

        do {
            System.out.println("Enter Phone Number");
            temp = sc.next();
            flag=v.PhoneNumberValidation(temp);
            if (flag)
            {
                sd.setPhoneNumber(Integer.parseInt(temp));
            }
        }while (!flag);


        do {
            System.out.println("Enter Adhar Number");
            temp = sc.next();
            flag=v.AdharNumberValidation(temp);
            if (flag)
            {
                sd.setAdharNumber(Long.parseLong(temp));
            }
        }while (!flag);
*/
        do {
            System.out.println("Create your Password");
            temp = sc.next();

            System.out.println("Re-Enter your Password");
            String temp1 = sc.next();

            if (temp.equals(temp1)) {
                System.out.println("Password created Successfully");
                sd.setPassword(temp);
                flag = true;
            }
            else
            {
                System.out.println("Password not Matched");
            flag = false;
            }

        }while(!flag);


        if (setInputDetails())
        {
            return sd;
        }

        return null;
    }



    public boolean setInputDetails()
    {
        Scanner sc=new Scanner(System.in);
        String str;
        int choice;
        boolean flag=true;

        System.out.println("-----------------------------------Verify your details------------------------------");
        System.out.println("Account Number: "+sd.getAccountNumber());
        System.out.println("Account Name: "+sd.getAccountName());
        System.out.println("Father Name: "+sd.getFathername());
        System.out.println("Adress:"+sd.getAddress());
        System.out.println("Date Of Birth: "+sd.getDob());
        System.out.println("Phone Number: "+sd.getPhoneNumber());
        System.out.println("Adhar Number: "+sd.getAdharNumber());
        System.out.println("------------------------------------------------------------------------------------");
        while (flag)
        {
            System.out.println("Please Enter your Choice");
            System.out.println("1-Done 2-Reset 3-Cancel");
            str=sc.next();
            Validation v=new Validation();
            choice=v.choiceValidation(str);
            switch (choice)
            {
                case 1:
                flag=false;
                    return true;
                case 2:getInputDetails();
                    break;
                case 3:return false;
                default:System.out.println("Invalid choice");
                break;
            }
        }

        return false;
    }


}
