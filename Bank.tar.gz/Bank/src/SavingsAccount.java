import java.util.HashMap;
import java.util.Scanner;

public class SavingsAccount extends AccountType {
    HashMap<Integer,StoreDetails> account=new HashMap();
    StoreDetails sd;

    public void setSd(StoreDetails sd) {
        this.sd = sd;
    }

    public StoreDetails getSd() {
        return sd;
    }

    @Override
    public boolean OpenAccount() {
        System.out.println("****Savings account****");
        sd=new StoreDetails();
        setSd(sd.getInputDetails());
    if ( sd==null)
    {
        System.out.println("\n\n****Savings account not created****\n\n");
        return false;
    }
    else
    {
        account.put(sd.getAccountNumber(),getSd());
        System.out.println("\n\n**********Savings account Created successfully**********\n\n");
         return true;
    }
    }

    public boolean ConfirmAccount()
    {
        int accountNumber=0;
        String str;
        boolean flag=true;
        Scanner sc = new Scanner(System.in);


        do {
         try {
             System.out.println("Enter your Account Number\n");
             str = sc.next();
             accountNumber = Integer.parseInt(str);
             flag=false;
         } catch (Exception e) {
             System.out.println("Invalid Account number");
             flag=true;
         }

          System.out.println("Enter your Password\n");
          str=sc.next();

          if ((account.containsKey(accountNumber)) && (account.get(accountNumber).getPassword()==str))
          {
              System.out.println("####Successfully logged in####");
              functionality(account.get(accountNumber));
              //System.out.println("account exist");
              flag=false;
          }
          else {
              System.out.println("account not exist");
              flag=true;
          }

        }while (flag);
        //System.out.println("Existing account"+account.get(sd.getAccountNumber()));
        return false;
    }

    public void functionality(StoreDetails info)
    {


    }

}
