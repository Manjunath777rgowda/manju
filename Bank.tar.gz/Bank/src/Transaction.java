import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Transaction {
    private float balance=0;
    String str;
    float amount;
    boolean flag;
    Scanner sc=new Scanner(System.in);
    Validation v=new Validation();

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public float Deposite(float balance)
    {
        do {
            System.out.println("\nEnter amount to deposite");
            str = sc.next();
            if (v.amountValidation(str))
            {
                amount=Float.parseFloat(str);
                balance=balance+amount;
                System.out.println("\n\nRS."+amount+" Deposited Successfully");
                return balance;
                }
        }while (true);
    }

    public void Balance(float balance)
    {
        System.out.println("Your current Balance is: Rs."+balance);

    }

    public float Withdraw(float balance,float limit)
    {
        do {
            System.out.println("\nEnter amount to Withdraw");
            str = sc.next();
            if (v.amountValidation(str))
            {
                amount=Float.parseFloat(str);
                if(limit>amount && balance>amount)
                {
                    balance=balance-amount;
                    System.out.println("\n\nRS."+amount+" Withdraw Successfully");
                    return balance;
                }
                else
                {
                    System.out.println("Insufficient Balance");
                    return balance;
                }
            }

        }while (true);
    }


}
