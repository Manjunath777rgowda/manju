public class CurrentAccount extends AccountType {

    @Override
    public boolean OpenAccount() {
        System.out.println("Current account");
        return false;
    }
}
