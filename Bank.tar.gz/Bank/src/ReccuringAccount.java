import java.util.HashMap;
import java.util.Scanner;

public class ReccuringAccount extends AccountType{
    HashMap<Integer, StoreDetails> account = new HashMap();
    HashMap<Integer,Float> balanceSheet=new HashMap<Integer,Float>();

    StoreDetails sd;
    float initialamount=0;
    Transaction t;

    public void setSd(StoreDetails sd) {
        this.sd = sd;
    }

    public StoreDetails getSd() {
        return sd;
    }


    @Override
    public boolean OpenAccount() {

        Scanner sc = new Scanner(System.in);
        Validation v = new Validation();
        String str;
        System.out.println("****Reccuring account****");
        sd = new StoreDetails();
        boolean flag=true;

        setSd(sd.getInputDetails());

        if (sd == null) {
            System.out.println("\n\n****Reccuring account not created****\n\n");
            return false;
        } else
        {
            account.put(sd.getAccountNumber(), getSd());
            System.out.println("\n\n**********Reccuring account Created successfully**********\n\n");
            return true;
        }
    }


    public boolean ConfirmAccount() {
        int accountNumber = 0;
        String str;
        boolean flag = true;
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Enter your Account Number\n");
            str = sc.next();
            accountNumber = Integer.parseInt(str);
            flag = false;
        } catch (Exception e) {
            System.out.println("Invalid Account number");
            return false;
        }

        System.out.println("Enter your Password\n");
        str = sc.next();

        if ((account.containsKey(accountNumber)) && (account.get(accountNumber).getPassword()).equals(str)) {
            System.out.println("####Successfully logged in####");
            functionality(account.get(accountNumber).getAccountNumber());
        } else {
            System.out.println("account not exist");
            return false;
        }
        return false;
    }

    public void functionality(int accountNumber) {
        t=new Transaction();
        Scanner sc = new Scanner(System.in);
        int choice;
        Validation v = new Validation();
        float temp=initialamount;
        balanceSheet.put(accountNumber,temp);
        while (true) {
            System.out.println("Press 1-Create_RD 2-Details 3-Withdraw 4-logout");
            String str = sc.next();
            choice = v.choiceValidation(str);
            switch (choice) {
                case 1:temp=t.Deposite(temp);
                    balanceSheet.put(accountNumber,temp);
                    break;
                    /*
                case 2: t.Balance(balanceSheet.get(accountNumber));
                    break;
                case 3:temp=t.Withdraw(temp,0);
                    balanceSheet.put(accountNumber,temp);
                    break;
                case 4:System.out.println("####----Logged out Successfully----####");
                    return;
                    */
                default: System.out.println("\n\nInvalid choice");
            }
        }

    }

}
