import java.time.LocalDate;
import java.util.*;

public class ReccuringAccount extends AccountType{
    private int refferenceNumber=0;
    private String nomineeName=null;
    private LocalDate depositeDate;
    private String relationship;
    private int period=0;

    HashMap<Integer, StoreDetails> account = new HashMap();
    ArrayList<ReccuringAccount> depositeList=new ArrayList<>();

    StoreDetails sd;
    ReccuringAccount rd;
    float initialamount=0;
    Transaction t;

    public void setSd(StoreDetails sd) {
        this.sd = sd;
    }

    public StoreDetails getSd() {
        return sd;
    }


    @Override
    public boolean OpenAccount() {

        Scanner sc = new Scanner(System.in);
        Validation v = new Validation();
        String str;
        System.out.println("****Reccuring account****");
        sd = new StoreDetails();
        boolean flag=true;

        setSd(sd.getInputDetails());

        if (sd == null) {
            System.out.println("\n\n****Reccuring account not created****\n\n");
            return false;
        } else
        {
            account.put(sd.getAccountNumber(), getSd());
            System.out.println("\n\n**********Reccuring account Created successfully**********\n\n");
            return true;
        }
    }


    public boolean ConfirmAccount() {
        int accountNumber = 0;
        String str;
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("Enter your Account Number\n");
            str = sc.next();
            accountNumber = Integer.parseInt(str);
        } catch (Exception e) {
            System.out.println("Invalid Account number");
            return false;
        }

        System.out.println("Enter your Password\n");
        str = sc.next();

        if ((account.containsKey(accountNumber)) && (account.get(accountNumber).getPassword()).equals(str)) {
            System.out.println("\n\n####Successfully logged in####");
            functionality();
        } else {
            System.out.println("account not exist");
            return false;
        }
        return false;
    }

    public void functionality() {
        Scanner sc = new Scanner(System.in);
        int choice;
        Validation v = new Validation();
        while (true) {
            System.out.println("Press 1-Create_RD 2-Show_All_Deposite 3-View_Details 4-logout");
            String str = sc.next();
            choice = v.choiceValidation(str);
            switch (choice) {
                case 1: CreateRD();
                    break;
                case 2: Rddetails();
                    break;
                    case 3 :ViewDetails();
                    break;

                case 4:System.out.println("\n\n####----Logged out Successfully----####");
                    return;

                default: System.out.println("\n\nInvalid choice");
            }
        }

    }

    public void CreateRD() {

        rd = new ReccuringAccount();
        Validation v = new Validation();
        Scanner sc = new Scanner(System.in);
        String temp;
        int choice;
        boolean flag = true;


        Random rand = new Random();
        int number = rand.nextInt(999) + 1000;
        rd.refferenceNumber = number;

        rd.depositeDate=java.time.LocalDate.now();

        while(flag)
        {
            System.out.println("Enter Amount to Deposite");
            temp=sc.next();
            rd.initialamount=v.choiceValidation(temp);
            if(rd.initialamount>=1000)
            {
                flag=false;
            }
            else System.out.println("Please enter valid Amount");
        }

        flag=true;

        while(flag)
        {
            System.out.println("\n\nEnter Deposite Period in Months\n***Warning!!! Month Should be greater than 6 months and lesser than 120 months");
            temp=sc.next();
            rd.period=v.choiceValidation(temp);
            if(rd.period>=6 && rd.period<=120)
            {
                flag=false;
            }
            else System.out.println("Please enter valid Period");
        }



        do {
            System.out.println("Enter Nominee Name");
            temp = sc.next();
            flag = v.nameValidation(temp);
            if (flag) {
                rd.nomineeName=temp;
            } else System.out.println("Enter valid Name");
        } while (!flag);

        flag=true;
        while (flag) {
            System.out.println("Select Relationship 1-Parents 2-Spouce 3-Sibling");
            String str = sc.next();
            choice = v.choiceValidation(str);
            switch (choice) {
                case 1:
                    rd.relationship = "Parents";
                    flag = false;
                    break;
                case 2:
                    rd.relationship = "Spouce";
                    flag = false;
                    break;
                case 3:
                    rd.relationship = "Sibling";
                    flag = false;
                    break;
                default:
                    System.out.println("\n\nInvalid choice");
                    flag = true;
                    break;
            }
        }

            if (setRdDetails())
            {
                depositeList.add(rd);
                System.out.println("\n\n####-----Deposited Successfully-----####\n\n");
            }

    }

    public boolean setRdDetails()
    {
        Scanner sc=new Scanner(System.in);
        String str;
        int choice;
        System.out.println("-----------------------------------Verify your details------------------------------");
        System.out.println("Refference Number    : "+rd.refferenceNumber);
        System.out.println("Deposite amount      : "+rd.initialamount);
        System.out.println("Deposite Period      : "+rd.period);
        System.out.println("Deposite Date        : "+rd.depositeDate);
        System.out.println("Nominee Name         : "+rd.nomineeName);
        System.out.println("Nominee Relationship : "+rd.relationship);
        System.out.println("------------------------------------------------------------------------------------\n");
        while (true)
        {
            System.out.println("Please Enter your Choice");
            System.out.println("1-Done 2-Cancel");
            str=sc.next();
            Validation v=new Validation();
            choice=v.choiceValidation(str);
            switch (choice)
            {
                case 1:
                    return true;
                case 2:
                    return false;
                default:System.out.println("Invalid choice");
                    break;
            }
        }
    }

    public void Rddetails()
    {
       if (depositeList.size()==0)
       {
           System.out.println("\n\n----Sorry!!!! There is no Deposite Available----\n\n");
           return;
       }
        System.out.println("\n\n\n-------------------------------Reccuring Deposite Recods------------------------------------");
       System.out.println("\nSl no\tRefference_Id\tDeposite_Amount\tDeposite_Date\n");

       for (int i=0;i<depositeList.size();i++)
       {
           ReccuringAccount temp=new ReccuringAccount();
           temp=depositeList.get(i);
           System.out.println((i+1)+"\t\t"+temp.refferenceNumber+"\t\t\t"+temp.initialamount+"\t\t\t"+temp.depositeDate+"\n\n");
       }
        System.out.println("------------------------------------------------------------------------------------------\n\n\n");
    }

    public void ViewDetails()
    {
        Scanner sc = new Scanner(System.in);
        Validation v = new Validation();
        boolean flag=true;
        int refferenceId;

        do {
            System.out.println("Enter the Refferece number");
            String str = sc.next();
            refferenceId = v.choiceValidation(str);
            if (refferenceId==0)
                System.out.println("Invalid Refference ID");
        }while (refferenceId==0);

        if (depositeList.size() > 0)
        {

            for (int i=0;i<depositeList.size();i++)
            {
                ReccuringAccount temp = new ReccuringAccount();
                temp = depositeList.get(i);

                if (temp.refferenceNumber == refferenceId)
                {
                    System.out.println("\n\n------------------------------Reccuring Deposite Details------------------------------");
                    System.out.println("|   |                       | ");
                    System.out.println("|1. | Refference Number     | " + temp.refferenceNumber);
                    System.out.println("|2. | Nominee Name          | " + temp.nomineeName);
                    System.out.println("|3. | Deposite amount       | " + temp.initialamount);
                    System.out.println("|4. | Deposite Period       | " + temp.period);
                    System.out.println("|5. | Deposite Date         | " + temp.depositeDate);
                    System.out.println("|6. | Installment Remaining | " + (temp.period - 1));
                    System.out.println("|7. | Total Deposite        | " + (temp.initialamount * temp.period));
                    System.out.printf("|8. | Intrest               | %.2f\n", ((temp.initialamount * temp.period) * 0.04));
                    System.out.println("|9. | Total Amount          | " + (((temp.initialamount * temp.period) * 0.04) + (temp.initialamount * temp.period)));
                    System.out.println("|   |                       | ");
                    System.out.println("------------------------------------------------------------------------------------\n\n");
                    flag=false;
                    return;
                }
            }


        }
        else{
            System.out.println("Sorry!!! There is no record for Refference Number " + refferenceId);
            flag=false;
        }

        if (flag==true)
        {
            System.out.println("Sorry!!! There is no record for Refference Number " + refferenceId);

        }
    }


}
