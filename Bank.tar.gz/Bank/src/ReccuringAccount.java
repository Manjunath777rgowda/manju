public class ReccuringAccount extends AccountType{

    @Override
    public boolean OpenAccount() {
        System.out.println("Reccuring account");
        return false;
    }
}
