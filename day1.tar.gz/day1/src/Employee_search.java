import java.util.Scanner;

import static java.lang.System.exit;


public class Employee_search extends Employee {
    Employee e[]=new Employee[20];

    Employee_search()
    {
        for(int i=0;i<e.length;i++)
            e[i]=new Employee();
    }
    public int  count;


    public void setCount(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }

    public void choice() {
    int ch = 0;
    Scanner s = new Scanner(System.in);
    int i = 0;
    while (true) {
        System.out.println("press 1-add 2-list 3-search 4-exit\nenter your choice\n\n");
        ch = s.nextInt();
        switch (ch) {
            case 1:
                e[i] = new Employee();
                e[i].add();
                setCount(++i);
                break;

            case 2:
                if (count > 0) {
                    System.out.println("Employee_Number Employee_Name Joining_Date");

                    for (int x = 0; x < count; x++) {
                        e[x].list(e[x]);
                    }
                    System.out.println("*****************************************");
                } else System.out.println("there are no list present\n");
                break;

            case 3:
                System.out.println("enter the search key word\n");
                String str = s.next();
                Employee_search es = new Employee_search();
                int flag=0;
                for (i=0;i<count;i++)
                {
                    flag = es.search(str,(e[i].getEmployeeNumber()),(e[i].getEmployeeName()),(e[i].getJoiningDate()));
                }
                if (flag != 1) {
                    System.out.println(str + " not found!!");
                }
                break;

            case 4:
                exit(0);

                default: System.out.println("enter valid Choice\n");
        }

    }

}
    public int search(String key,String number,String name,String date)
    {
       for (int i=0;i<e.length;i++)
        {
            while(number.equals(key)||name.equals(key)||date.equals(key))
            {
                System.out.println("Employee name:"+name);
                System.out.println("Employee number:"+number);
                System.out.println("Joining date:"+date);
                return 1;
            }
        }

        return 0;
    }

    public static void main(String[] args)
    {
       Employee_search sc=new Employee_search();
       sc.choice();

    }
}
