import java.lang.*;

public class Rectangle {
  private  float length,breadth,area;

      public Rectangle() {
         length=1;
         breadth=1;
     }

    public int setLength(float length) {

          if(length>0.0 && length<20.0) {
              this.length = length;
          }
          else return 0;
          return 1;
    }

    public int setBreadth(float breadth) {
          if(breadth>0.0 && breadth<20.0)
          {
              this.breadth = breadth;
          }
          else

              return 0;
        return 1;
    }

    public float getLength() {
        return length;
    }

    public float getBreadth() {
        return breadth;
    }

    public float calculate(){
         area=length*breadth;

       float perimeter=2*(length+breadth);
        return area;
    }



    public void display(){
        System.out.println("lenght:"+getLength());
        System.out.println("breadth:"+getBreadth());
        System.out.printf("area:%.2f\n",calculate());
        System.out.printf("Perimeter:%.2f",calculate());
    }

   public static void main(String[] args) {


        Rectangle r1=new Rectangle();
        r1.calculate();
        r1.display();

    }
}