import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;
import  java.util.Map.Entry;

import static java.lang.System.exit;

public class hashmap {

    public static void main(String[] args){

        hashmap hashObject=new hashmap();
        HashMap<Integer,String> hm1=new HashMap<Integer, String>();


        while(true){
            System.out.println("Press 1-add 2-show 3-delete 4-exit\nenter the choice\n");
            Scanner sc=new Scanner(System.in);
            String str="";
            str=sc.next();
            int choice=0;
            try {
                choice=Integer.parseInt(str);
            }
            catch (Exception e){
                System.out.println("Enter valid choice");
               continue;
            }
            switch (choice)
            {
                case 1:
                    int key=0;
                    System.out.println("enter the key");
                    str=sc.next();
                    try {
                        key=Integer.parseInt(str);
                    }
                    catch (Exception e){
                        System.out.println("Enter valid key");
                        continue;
                    }


                    String value="";
                    System.out.println("enter the value");
                    value=sc.next();
                    hm1.put(key,value);
                        break;

                    case 2:
                        if(hm1.isEmpty()){
                            System.out.println("HashMap is Empty");
                        }
                        else{
                            for(Entry e: hm1.entrySet())
                                System.out.println("{"+e.getKey()+"->"+e.getValue()+"}");
                        }

                    break;

                case 3: if(hm1.isEmpty()){
                          System.out.println("HashMap is Empty");
                          continue;
                      }
                      else {
                          try {
                              System.out.println("enter key to delete");
                              str=sc.next();
                              key = Integer.parseInt(str);
                              if (hm1.containsKey(key)) {

                                  hm1.remove(key);
                                  System.out.println("deleted successfully!!!");
                              }
                              else
                              {
                                  System.out.println("HashMap Doent contain key:"+key);
                              }
                              break;
                          } catch (Exception e) {
                              System.out.println("Enter valid key");
                              continue;
                          }
                      }
                case 4:exit(0);
                    break;
                default: System.out.println("Enter the valid choice");
            }

        }

    }
}
