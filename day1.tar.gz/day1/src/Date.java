import java.net.Inet4Address;
import java.util.Scanner;

import static java.lang.System.exit;
import static java.lang.System.in;

public class Date {
    private int day,month,year;
    private int resultDay,resultMonth,resultYear;

    public Date()
    {
     day=20;
     month=9;
     year=1996;
     //resultDay=getDay();
     //resultMonth=getMonth();
     //resultYear=getYear();
    }
//---------------------------getter and setter function---------------------------------------------------------------------------//
    public void setDay(int day) {
        this.day = day;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public void setResultDay(int resultDay) {
        this.resultDay = resultDay;
    }

    public void setResultMonth(int resultMonth) {
        this.resultMonth = resultMonth;
    }

    public void setResultYear(int resultYear) {
        this.resultYear = resultYear;
    }

    public int getResultDay() {
        return resultDay;
    }

    public int getResultMonth() {
        return resultMonth;
    }

    public int getResultYear() {
        return resultYear;
    }

    //--------------------------End of getter and setter function---------------------------------------------------------------------//

//------------------------------Date validation method---------------------------------------------------------------------------//

    public int validate(int day, int month, int year)
    {
        //System.out.println("validate");
        if(day>31 || month>12 || year==0 || day<=0 ||month<=0||year<=0)
        {
            System.out.println("*****invalid date*****\nPlease enter valid date\n");
           return 0;
        }

        //checking for leap year constrain
        LeapYear lp=new LeapYear();

         if(month==2)
         {
            if(lp.cheackLeapYear(year)==1)
            {
                if (day>29)
                {
                    System.out.println(year+" is a leap year, feb should be less than or equal to 29\n Please enter valid date\n");
                    return 0;
                }
            }

            else if(day>28)
            {
               System.out.println("****febraury can not have more than 29****\nPlease enter valid date");
               return 0;
            }
         }


         else if((month==4||month==6||month==9||month==11) && day>30)
         {
            System.out.println("****This month dont have "+day+"****\nPlease enter valid date");
            return 0;
         }

        return 1;
    }
//----------------------------------End of Date validation method-----------------------------------------------------------------//

//-----------------------------------Method to add Date---------------------------------------------------------------------------//
public int addDate()
{
    LeapYear lp=new LeapYear();
    Scanner s=new Scanner(System.in);
    int flag;
    int day=0,month=0,year=0;
    int oldMonth=getMonth();
    try {
        System.out.println("Enter no of days");
            String strInput = s.next();
            int inputDays=Integer.parseInt(strInput);
            if(inputDays<0) {
                System.out.println("****Invalid no of days*****\n");
                return 0;
            }
                switch (oldMonth)
                {
                    case 1:
                    case 3:
                    case 5:
                    case 7:
                    case 8:
                    case 10:
                       if ((inputDays+getDay())<=31){
                           day=getDay()+inputDays;
                           setResultDay(day);

                       }
                                else
                       {
                           day=(inputDays+getDay())-31;
                           month=getMonth()+1;
                           setResultMonth(month);
                           setResultDay(day);
                       }

                        break;

                    case 4:
                    case 6:
                    case 9:
                    case 11:    if((inputDays+getDay())<=30){
                        day=getDay()+inputDays;
                        setResultDay(day);

                    }

                    else if ((inputDays+getDay())>30) {
                      day = (inputDays+getDay())-30;
                        month = getMonth() + 1;
                        setResultMonth(month);
                    }

                        break;

                    case 12:
                        if ((inputDays+getDay())<=31)
                        {
                            day=getDay()+inputDays;
                            setResultDay(day);

                        }

                        else
                        {
                            day=(inputDays+getDay())-31;
                            year=getYear()+1;
                            setResultYear(year);
                            setResultMonth(1);
                            setResultDay(day);
                        }

                        break;

                        case 2:

                                 if ((lp.cheackLeapYear(getYear()) == 1)) {
                                     if ((inputDays + getDay()) <= 29) {
                                         day = (inputDays + getDay());
                                         setResultDay(day);
                                     } else {
                                         if ((inputDays + getDay()) > 29) {
                                             day = (inputDays + getDay()) - 29;
                                             month = getMonth() + 1;
                                             setResultMonth(month);
                                             setResultDay(day);
                                         }
                                     }

                                 }

                                 else {
                                     if ((inputDays + getDay()) <= 28) {
                                         day = getDay() + inputDays;
                                         setResultDay(day);
                                     } else {
                                         day=(inputDays + getDay())-28;
                                         month=getMonth()+1;
                                         setResultDay(day);
                                         setResultMonth(month);

                                     }
                                 }


                        break;

                }



    }

    catch(Exception e){
        System.out.println("****Invalid no of days*****\n");
        return 0;


    }
    return 1;
}
//-----------------------------------Method to add Date---------------------------------------------------------------------------//


    public static void main(String[] args){
        Date dateObj=new Date();
        int  flag;
        System.out.println("enter the DD/MM/YYYY");
        Scanner s=new Scanner(System.in);

            try {
                do {
                    String strDay = s.next();
                    //System.out.print("/");
                    String strMonth = s.next();
                   // System.out.print("/");
                    String strYear = s.next();

                    int day=Integer.parseInt(strDay);
                    int month=Integer.parseInt(strMonth);
                    int year=Integer.parseInt(strYear);

                    flag = dateObj.validate(day, month, year);
                    if (flag==1)
                    {
                        dateObj.setDay(day);
                        dateObj.setResultDay(day);
                        dateObj.setMonth(month);
                        dateObj.setResultMonth(month);
                        dateObj.setYear(year);
                        dateObj.setResultYear(year);
                    }
                }while (flag==0);

            }

            catch(Exception e){
                System.out.println("****DD/MM/YYYY should be integer*****\n");
                exit(0);
            }

            do{
                flag=dateObj.addDate();
                if(flag==1)
                {
                    System.out.println("###-----No of days added successfully------###\n");
                    System.out.println("Result date is : "+dateObj.getResultDay()+"-"+dateObj.getResultMonth()+"-"+dateObj.getResultYear());
                }

            }while (flag==0);




    }
}
