import java.util.Scanner;

public class book_detail {

    Scanner s=new Scanner(System.in);
    int n;
    book b[]=new book[20];

    public void createBooks() {

        System.out.println("enter the number of books");
        n = s.nextInt();

        for (int i = 0, count = 1; i < n; i++) {
            b[i] = new book();
            System.out.println("enter the details for book" + count++);

            System.out.println("enter book title");
            String temp = s.next();
            b[i].setBook_title(temp);

            System.out.println("enter book price");



            try{
                String x = "";
                x = s.next();
               Float num = Float.parseFloat(x);
                if (num <= 0) {
                    System.out.println("enter valid Book_price");
                    i--;
                    count--;
                    continue;
                }
                else b[i].setBook_price(num);


            }catch (NumberFormatException ex) {
                System.out.println("enter valid Book_price");
                i--;
                count--;
                continue;
            }
            }
        }
    public void showBooks(){
        System.out.println("\n\n******Details of Book******\n");
        System.out.println("Book_title  Book_price");
        for (int i=0;i<n;i++) {

            System.out.println(b[i].getBook_title()+"           Rs."+b[i].getBook_price());

        }
    }

    public static void main(String[] args){
        book_detail bd=new book_detail();
        bd.createBooks();
        bd.showBooks();

    }

}
