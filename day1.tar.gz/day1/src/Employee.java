import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import static java.lang.System.exit;

public class Employee {

    private  String employeeNumber;
    private  String employeeName;
    private  String joiningDate;

    public Employee(){
        employeeName="";
        employeeNumber="";
        joiningDate="";
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public void add(){
        Scanner s=new Scanner(System.in);
        System.out.println("enter the Employee Number");
        String sc=s.next();
        setEmployeeNumber(sc);
        System.out.println("enter the Employee Name");
        sc=s.next();
        setEmployeeName(sc);
        System.out.println("enter the Employee Joining Date in DD/MM/YYYY");
        sc=s.next();
        setJoiningDate(sc);
   }

    public void list(Employee e)
    {
        System.out.println(e.getEmployeeNumber()+" \t\t\t"+e.getEmployeeName()+" \t\t\t"+e.getJoiningDate());

    }

    public void search()
    {

    }

    public static void main(String[] args){
        Employee e[]=new Employee[10];
        for (int i=0;i<10;i++){
            e[i]=new Employee();
        }

       // System.out.println("\n1-add 2-list 3-search\nenter your choice\n");

    }

}
