import java.util.Scanner;

public class HashMap_implemented {
    public static void main(String[] args)
    {
        Entry<Integer,String> e=new Entry<Integer, String>(0,"",null);
        Scanner sc=new Scanner(System.in);
        System.out.println("enter key and value\n");
        e.key=sc.nextInt();
        e.value=sc.next();
        e.put();
    }
}
