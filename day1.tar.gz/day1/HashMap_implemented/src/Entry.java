import java.util.ArrayList;

class Entry<K, V> {
    K key;
    V value;
    Entry<K,V> next;
    ArrayList<Entry> bucket=new ArrayList<Entry>();


    public Entry(K key, V value, Entry<K,V> next){
        this.key = key;
        this.value = value;
        this.next = next;
    }

    public void put(){
        int index=Integer.parseInt(String.valueOf(key))%4;
        System.out.println("index="+index);

        Entry<K,V> newEntry=new Entry<K,V>(key,value,next);
        bucket.add(newEntry);
        //a=bucket.get(index-1) ;
        //System.out.println(a.key);

    }

   }
