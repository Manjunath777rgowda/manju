import java.util.ArrayList;

public class arraylist {
    int x;
    public arraylist()
    {
        x=3;
    }
    public static void main(String[] args)
    {
        arraylist ar=new arraylist();
        ArrayList<Object> ar1=new ArrayList<Object>();//rraylist();
        ar1.add(ar);
        arraylist a= (arraylist) ar1.get(0);
        System.out.println(a.x);
    }
}
