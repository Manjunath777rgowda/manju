import java.util.Scanner;

public class CustomHashMapImplemented{
	
	public static void main(String[] args)
		{
			CustomHashMap<Integer,String> myHashMap=new CustomHashMap();
			while(true){
            System.out.println("Press 1-add 2-show 3-delete 4-get 5-clear 6-exit\nenter the choice\n");
            Scanner sc=new Scanner(System.in);
            String str="";
            str=sc.next();
            int choice=0;
            try {
                choice=Integer.parseInt(str);
            }
            catch (Exception e){
                System.out.println("Enter valid choice");
               continue;
            }
            switch (choice)
            {
                case 1:
                    int key=0;
                    System.out.println("enter the key");
                    str=sc.next();
                    try {
                        key=Integer.parseInt(str);
                    }
                    catch (Exception e){
                        System.out.println("Enter valid key");
                        continue;
                    }
                    
                    String value="";
                    System.out.println("enter the value");
                    value=sc.next();
                    myHashMap.put(key,value);
                        break;

                    case 2:
                        if(myHashMap.isEmpty()){
                            System.out.println("HashMap is Empty");
                        }
                        else{
                        	myHashMap.show();
                        }

                    break;

                case 3:    try {
                              System.out.println("enter key to delete");
                              str=sc.next();
                              key = Integer.parseInt(str);
                              myHashMap.remove(key);
                          } 
                			catch (Exception e) {
                              System.out.println("Enter valid key");
                              continue;
                          }
                      break;
                case 4: try {
                    System.out.println("enter key to retrive value");
                    str=sc.next();
                    key = Integer.parseInt(str);
                    myHashMap.get(key);
                } 
      			catch (Exception e) {
                    System.out.println("Enter valid key");
                    continue;
                }
                	break;
                case 5:myHashMap.clearAll(); 
                	break;
                      case 6:System.exit(0);
                    break;
                default: System.out.println("Enter the valid choice");
            }

        }

    }
}
