import java.util.Scanner;

public class CustomHashMap<K,V> extends Entry<K,V> {
	Entry<K,V> head=new Entry<K,V>();
	Entry<K,V> last=new Entry<K,V>();
     int length;
     
	 public CustomHashMap()
	 {
		 head=null;
		 last=null;
		 length=0;
	 }
	 
	 public boolean isEmpty()

	 {
		 return length==0;
	 }
	 
	 public int length()
	 {
		 return length;
	 }

	 public Entry isContain(K key)

	 {
		 Entry temp=new Entry();
		 temp=head;
		 while(temp!=null)
		 {
			 if(temp.key==key)
			 {
				 return temp;
			 }
			 temp=temp.next;
		 }
		 return null;
	 }

	 public void replace(Entry newNode,V value)
	 {
		  //newNode=isContain(key);
			 newNode.value=value;
		//return;
	 }
	 
	 public void put(K key,V value)

	 {
		 Entry<K,V> newNode=new Entry<K, V>();
		 newNode.key=key;
		 newNode.value=value;
		 
		 if(isEmpty())
		 {
			 head=newNode;
		 }
		 else if(isContain(key)!=null)
		 {
			 replace(isContain(key),value);
			 return;
		 }
		 else
		 {
			 last.next=newNode;
			 newNode.previous=last;		 
		 }
		 last=newNode;
		 length++;
	 }
	 
	 public V get(K key)
	 {
		Entry<K,V> node=new Entry<K,V>();
		node=head;
		while(node!=null)
		{
			if(node.key==key)
				return node.value;
			node=node.next;
		}
		System.out.println("no data for key:"+key);
		return null; 
	 }
	 
	 public void show()
	 {
		 Entry<K,V> temp=new Entry<>();
		 if(head==null)
		 {
			 System.out.println("list is empty");
			 return;
		 }
		 temp=head;
		 while(temp!=null)
		 {
			 System.out.println("{"+temp.key+"-->"+temp.value+"}");
			 temp=temp.next;
		 }		 	 
	 }
	
	 public boolean remove(K deleteKey)
	 {
		 Entry<K,V> node=new Entry<>();
		 node=head;
		 if(isEmpty())
		 {
			 System.out.println("HashMap Empty");
		 }
		 if(node.previous==null && node.key==deleteKey)
		 {
			 head=node.next;
			 head.previous=null;
			 return true;
		 }
		 else
		 {
			 while(node!=null)
			 {
				 if(node.key==deleteKey)
				 {
					 if(node==last)
					 {
						 node.previous.next=null;
						 return true;
					 }
					 node.previous.next=node.next;
					 node.next.previous=node.previous;
					 return true;
				 }
				 node=node.next;
			 }
			 }
		 System.out.println("key not found");
		
		  return false;
	 }
	 
	 public void clearAll()
	 {
		 if(isEmpty())
		 {
			 System.out.println("HashMap Empty");
			return;
		 }
		 head=null;
		 last=null;
	 }
/*	 public static void main(String[] args){
		CustomHashMap<Integer,String> a=new CustomHashMap<Integer,String>();
		a.put(1, "aaaa");
		a.put(2, "bbbb");
	    a.put(3, "cccc");

	    a.show();
		
		System.out.println(a.remove(3));
		a.show();
		
		a.clearAll();
		a.show();
		
		
  }*/
}
