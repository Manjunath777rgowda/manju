import java.util.Scanner;

public class HashMap_implemented {
public static void main(String[] args){
    int c=-1,p;
    for (int i=0;i<10;i++)
    {
        p=c;
        System.out.println("p="+p);
        if(true)
        {
            c=i;
            System.out.println("***c="+c);

        }
    }
}
}
