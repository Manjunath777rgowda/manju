import java.util.ArrayList;

public class MyHashMap<K,V> extends Entry<K,V>{

        Entry head=null;
        Entry last=new Entry();
    Entry current=new Entry();
    Entry previous=new Entry();
    Entry temp=new Entry();

        public boolean put(K key,V value){
        Entry<K,V> newEntry=new Entry<K, V>();
        newEntry.key=key;
        newEntry.value=value;
        newEntry.next=null;

        if(head==null) {
            head=new Entry();
           // System.out.println("head is added\n");
            head=newEntry;
            last=newEntry;
        }
        else
        {
            /*
            *
            while (node.next != null) {
                if (node.key == deleteKey) {
                    current = node;
                    temp = previous;
                    temp.next = current.next;
                    return true;
                }

                if (node != null) {
                    previous = node;
                    // System.out.println("pre="+previous.key);
                }
                node = node.next;
            * */
            Entry<K,V> node=new Entry<K,V>();
            node=head;
            previous = head;
            while (node.next!=null)
            {
                if (node.key == key) {
                    current = node;
                    temp = previous;
                    temp.next = newEntry;
                    temp=temp.next;
                    temp.next=current.next;

                    return true;
                }

                if (node != null) {
                    previous = node;
                    // System.out.println("pre="+previous.key);
                }


                node=node.next;
            }
            node.next=newEntry;
            last=newEntry;
            return true;
        }
        return false;
    }


    public void showHashMap() {
        Entry<K, V> node = new Entry<K, V>();
        node = head;

        if (head == null) {
            System.out.println("Hashmap is Empty");
        } else {
            while (node.next != null) {
                System.out.println("{" + node.key + "->" + node.value + "}");
                node = node.next;
            }
            System.out.println("{" + node.key + "->" + node.value + "}");
        }
    }


    public V get(K key)
    {
        Entry<K,V> node=new Entry<>();
        node=head;
        while (node.next!=null)
        {
            if(node.key==key)
            {
                return node.value;
            }
        }
        return null;
    }

    public boolean remove(K deleteKey)
    {
        Entry<K,V> node=new Entry<>();
        node=head;

        temp=head;

        if(head.key==deleteKey)
        {
            head=head.next;
           // System.out.println("head removed");
            return true;
        }
        else if(last.key!=deleteKey)
            {
            previous = head;
            while (node.next != null) {
                if (node.key == deleteKey) {
                    current = node;
                    temp = previous;
                    temp.next = current.next;
                    return true;
                }

                if (node != null) {
                    previous = node;
                    // System.out.println("pre="+previous.key);
                }
                node = node.next;
            }
        }


        else
            {
                previous = head;
                while (node.next != null) {

                    if (node != null) {
                        previous = node;
                    }
                    node = node.next;
                }

                if (node.key == deleteKey) {
                    temp = previous;
                    temp.next = null;
                    return true;
                }

       }

        return false;
    }


public static void main(String[] args)
{
    MyHashMap<Integer,String> e=new MyHashMap<>();
    MyHashMap<Integer,Integer> e1=new MyHashMap<>();

e.put(1,"aaaa");
e.put(2,"bbbb");
e.put(3,"bbbb");
e.put(4,"bbbb");
e.put(5,"bbbb");
/*
e1.put(1,1);
e1.put(2,2);
e1.put(3,3);
e1.put(4,4);
e1.put(5,5);

e.showHashMap();
System.out.println("************");
e1.showHashMap();

if (e.remove(1))
  {
      System.out.println("removed successfully");
  }
else       System.out.println("key not present");

    e.showHashMap();*/


    e.showHashMap();
    System.out.println("************");
    e.put(5,"aaa");
    e.showHashMap();

}

}
