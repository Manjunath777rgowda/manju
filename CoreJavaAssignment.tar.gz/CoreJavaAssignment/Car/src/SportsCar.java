public class SportsCar extends Car{
/*
The class SportCar is derived from the class Car which adds new features AirBallonType.
When this method is invoked, initial speed and gear status must be displayed on console.
Override the display method which display all attribute of the SportCar.
* */
int speed;
int noOfGear;
public void AirBallon()
{
    speed=100;
    noOfGear=7;
}

    @Override
    public void display() {
        super.display();
        System.out.println("SPORTSCAR CLASS");
        System.out.println(" Speed is"+speed+"kmph and  it has"+noOfGear+"gears");
    }

public static void main(String[] args)
{
    SportsCar c=new SportsCar();
    c.AirBallon();
    c.display();
}
}
