public class Piano extends Instrument {
    void play() {
        System.out.println("Piano is playing  tan tan tan tan ");

    }
}
