public class Guitar extends Instrument {
    void play() {
        System.out.println("Guitar is playing  tin  tin  tin");

    }

    public static void main(String[] args)
    {

        Instrument g=new Guitar();
        Instrument f=new Flute();
        Instrument p=new Piano();

        g.play();
        f.play();
        p.play();

        Object[] ob=new Object[10];
        ob[0]=new Guitar();
        ob[1]=new Guitar();
        ob[2]=new Guitar();
        ob[3]=new Piano();
        ob[4]=new Piano();
        ob[5]=new Piano();
        ob[6]=new Flute();
        ob[7]=new Flute();
        ob[8]=new Flute();
        ob[9]=new Flute();
        for (int i=0;i<10;i++)
        {
            if(ob[i] instanceof Guitar)
            {
                System.out.println("ob["+i+"]is instance of Guitar");
            }
            else if(ob[i] instanceof Piano)
            {
                System.out.println("ob["+i+"]is instance of Piano");
            }
            else
            {
                System.out.println("ob["+i+"]is instance of Flute");
            }
        }
    }
}
