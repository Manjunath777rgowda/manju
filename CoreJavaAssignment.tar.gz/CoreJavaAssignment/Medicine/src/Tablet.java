public class Tablet extends Medicine {

    @Override
    public void display() {
        System.out.println("Tablet Class");
        super.display();
        System.out.println("store in a cool dry place");
    }
}
