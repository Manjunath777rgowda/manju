public class Syrup extends Medicine{
    @Override
    public void display() {
        System.out.println("Syrup Class");
        super.display();
        System.out.println("Shake well before use");
    }
}
