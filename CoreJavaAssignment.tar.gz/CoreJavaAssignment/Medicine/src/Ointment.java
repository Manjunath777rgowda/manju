public class Ointment extends Medicine {
    @Override
    public void display() {
        System.out.println("Ointment Class");
        super.display();
        System.out.println("for external use only");
    }
}
