public class Medicine {
    public String companyName;
    public String companyAddress;

    public Medicine(){
        companyName="vicks";
        companyAddress="banglore";
    }
   public void display(){
       System.out.println("Medicine company name="+companyName);
       System.out.println("Medicine company address="+companyAddress);
   }
}
