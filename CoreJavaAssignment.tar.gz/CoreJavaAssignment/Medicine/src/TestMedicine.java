import javafx.scene.control.Tab;

import java.util.Random;

public class TestMedicine {

    public static void main(String[] args) {
        Random rand = new Random();
        int n[]=new int[10];
        for(int i=0;i<10;i++) {
            n[i] = rand.nextInt(3) + 1;
            System.out.println("number of Medicine=" + n[i]);
        }

        System.out.println("************");

        Medicine[] m = new Medicine[10];
        for(int i=0;i<3;i++)
        {
            if(n[i]==1)
            {
                m[i]=new Tablet();
                m[i].display();
                System.out.println("************");

            }
            else if(n[i]==2)
            {
                m[i]=new Syrup();
                m[i].display();
                System.out.println("************");

            }
            else
            {
                m[i]=new Ointment();
                m[i].display();
                System.out.println("************");
            }
        }


}

}
