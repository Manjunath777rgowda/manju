public class General extends Compartment {
    void notice()
    {
        System.out.println("This is General Compartment");
    }
}
