import java.util.Random;

public class TestCompartment {

    public static void main(String[] args)
    {
        Compartment[] compartment=new Compartment[10];
        Random rand=new Random();

        int n[]=new int[10];
        for(int i=0;i<10;i++) {
            n[i] = rand.nextInt(4) + 1;
            System.out.println("number of Medicine=" + n[i]);
        }
        System.out.println("************");


        Compartment[] m = new Compartment[10];
        for(int i=0;i<10;i++)
        {
            if(n[i]==1)
            {
                m[i]=new FirstClass();
                m[i].notice();
                System.out.println("************");

            }
            else if(n[i]==2)
            {
                m[i]=new Ladies();
                m[i].notice();
                System.out.println("************");

            }
            else if(n[i]==3)
            {
                m[i]=new General();
                m[i].notice();
                System.out.println("************");
            }
            else
            {
                m[i]=new Luggage();
                m[i].notice();
                System.out.println("************");
            }
        }


    }
}
