public abstract class Compartment {
    abstract void notice();
}
