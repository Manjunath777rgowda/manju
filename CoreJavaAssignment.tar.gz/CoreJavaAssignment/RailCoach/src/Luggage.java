public class Luggage extends Compartment{
    void notice()
    {
        System.out.println("This is Luggage Compartment");
    }
}
