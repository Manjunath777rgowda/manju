public class Ladies extends Compartment{
    void notice()
    {
        System.out.println("This is Ladies Class Compartment");
    }
}
