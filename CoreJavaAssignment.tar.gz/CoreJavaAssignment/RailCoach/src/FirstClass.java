public class FirstClass extends Compartment {
    void notice()
    {
        System.out.println("This is First Class Compartment");
    }
}
