import java.util.Scanner;

public class CommandlineArguements {
    static Scanner sc=new Scanner(System.in);

    public static boolean validateData(String a,String b)
    {
        try{
            Float.parseFloat(a);
            Float.parseFloat(b);
            return true;
        }
        catch (Exception e)
        {
            System.out.println("Invalid operand");
        }
        return false;
    }

    public static void main(String[] args)
    {
/*
        String[] args=new String[3];
        System.out.println("enter input");
        args[0]=sc.next();
        args[1]=sc.next();
        args[2]=sc.next();
*/
System.out.println("length"+args.length);
        if (args.length<=4 && validateData(args[0],args[2]))
        {
            float a=0,b=0,temp=0;
            a=Float.parseFloat(args[0]);
            b=Float.parseFloat(args[2]);

            switch (args[1])
            {
                case "+": temp=a+b;
                    System.out.println(a+"+"+b+"="+temp);
                    break;

                case "-":temp=a-b;
                    System.out.println(a+"-"+b+"="+temp);
                    break;

                case "*": temp=a*b;
                    System.out.println(a+"*"+b+"="+temp);
                    break;

                case "/":
                    try {
                        temp = a / b;
                        System.out.println(a+"/"+b+"="+temp);

                    }
                    catch (Exception e)
                    {
                        System.out.println("can not devide by zero");
                    }
                    break;
                default:System.out.println("Enter Valid operator");
            }
        }
        else
        {
            System.out.println("please enter valid Expression");
        }
    }
}
